    <!-- jQuery -->
    <script src="../../css/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../../css/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../../css/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../../css/bower_components/raphael/raphael-min.js"></script>
    <script src="../../css/bower_components/morrisjs/morris.min.js"></script>
    <script src="../../css/js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../../css/dist/js/sb-admin-2.js"></script>