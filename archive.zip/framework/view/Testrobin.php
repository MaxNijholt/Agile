<?php include 'inc/header.inc.php'; ?>
	<?php include 'inc/nav.inc.php'; ?>

	<div> Hello world - Test </div>

<?php include 'inc/footer.inc.php'; ?>