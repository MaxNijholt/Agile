<div class="container">
<h2>Admin Login Succes</h2>
<?php
echo "ingelogd als: ".$_SESSION['adminUsername'];
?>
</div>