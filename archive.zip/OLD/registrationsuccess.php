<!DOCTYPE html>
<?php include 'inc/header.inc.php'; ?>
<?php include 'inc/nav.inc.php'; ?>

    <div class="container">
    

        <div class="alert alert-success" style="margin-top: 50px;">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong>Success!</strong> Je bent succesvol geregistreerd
        </div>

    </div> <!-- /container -->

<?php include 'inc/footer.inc.php'; ?>
