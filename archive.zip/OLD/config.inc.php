<?php 

$database["location"] = "localhost";
$database["db_name"] = "toine.tjosti.nl";
$database["login"] = "root";
$database["password"] = "Tjosti2015@Mysql";

?>