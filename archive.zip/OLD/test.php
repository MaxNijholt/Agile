<?php

echo md5("test");

?>