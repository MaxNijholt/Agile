/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

(function($) {
	$(document).ready(function() {

		// E-mail validation
		var mailTimer = null;
		$("#email").keypress(function() {
			if(mailTimer != null)
				clearTimeout(mailTimer);

			var $this = $(this)
			  , $parent = $(this).parent();
			mailTimer = setTimeout(function() {
				$.getJSON('/register/check?mail=' + $this.val(), function(json) {
					if(json.error == false && json.response == true) {
						$parent.removeClass('has-error').addClass('has-success');
					} else {
						$parent.removeClass('has-success').addClass('has-error');
					}
				});
			}, 500);
		});

		// Password validation
		$passwd = $("#password1, #password2");
		$passwd.keyup(function() {
			// Check if passwords are not empty and longer 2
			if($("#password1").val().length >= 2 && $("#password2").val().length >= 2) {
				// Check if they are the same
				if($("#password1").val() == $("#password2").val()) {
					$passwd.parent().removeClass('has-error').addClass('has-success')
				} else {
					$passwd.parent().removeClass('has-success').addClass('has-error');
				}
			} else {
				$passwd.parent().removeClass('has-success').addClass('has-error');
			}
		});

		// Category Search
		var scatTimer = null;
		$scatTxt = $("#scat-txt");
		$scatResult = $(".scat-results");
		$scatTxt.keypress(function() {
			if(scatTimer != null)
				clearTimeout(scatTimer);

			var $this = $(this);
			if($scatTxt.val().length > 0) {
				$scatResult.html('<tr><td><i>Laden...</i></td></tr>');
				scatTimer = setTimeout(function() {
					$.getJSON('/admin/categories/search?name=' + $scatTxt.val(), function(json) {
						if(json.success && json.success == true && json.result.length > 0) {
							
							$scatResult.html('');
							var tr;
							for (var i = 0; i < json.result.length; i++) {
								tr = $("<tr>");
								tr.attr('data-id', json.result[i].id);
								tr.html('<td>' + json.result[i].name + '</td>');
								tr.click(function() {
									$("#cats-selected").html($(this).find('td').html());
									$("#cats-hidden").val($(this).attr('data-id'));
									$('#modalCategory').modal('hide');
								});
								$scatResult.append(tr);
							}

							

						} else {
							$scatResult.html('<tr><td><i>Er zijn geen categorie&euml;n gevonden.</i></td></tr>');
						}
					});
				}, 500);
			}
		});

		// Remove Product
		$mdlConfirm = $("#modalConfirm");
		$(".btn-remove-product").click(function() {
			$mdlConfirm.attr('data-id', $(this).attr('data-id')).modal('show');
		});

		$mdlConfirm.find('button.btn-primary').click(function() {
			$this = $(this);
			$this.button('loading');
			$.getJSON('/admin/products/remove/' + $mdlConfirm.attr('data-id'), function(json) {
				if(json.success) {
					$('.product[data-id="' + $mdlConfirm.attr('data-id') + '"]').fadeOut(250);
				}

				$mdlConfirm.modal('hide');
				$this.button('reset');
			});
		});


		// Tags
		var tagsTimer;
		$tags = $("#tags");
		$productTags = $("#product-tags");
		$productTagsResults = $("#product-tags-completion");
		$productTagsLabels = $(".form-group.tags .labels");
		$productTagsLabels.find('a').click(removeTagFromList);
		$productTags.keypress(function() {
			if(tagsTimer != null)
				clearTimeout(tagsTimer);

			if($productTags.val().length > 0) {
				tagsTimer = setTimeout(function() {
					$.getJSON('/admin/tags?name=' + $productTags.val(), function(json) {
						if(json.success == true) {
							$productTagsResults.html('');
							for (var i = 0, a; i < json.result.length; i++) {
								a = $("<a>");
								a.attr('href', 'javascript:void(0);');
								a.addClass('list-group-item');
								a.attr('data-tag', json.result[i]);
								a.html(json.result[i]);
								a.click(addTagToList);
								$productTagsResults.append(a);
							};

							a = $("<a>");
							a.attr('href', 'javascript:void(0);');
							a.addClass('list-group-item');
							a.attr('data-tag', $productTags.val());
							a.html($productTags.val() + '<span class="pull-right glyphicon glyphicon-plus"></span>');
							a.click(addTagToList);
							$productTagsResults.append(a).show(0);
						}
					})
				}, 500);
			}
		});

		function removeTagFromList() {
			if($tags.val() == '')
				var t = [];
			else 
				var t = $tags.val().split(',');
			var n = $(this).attr('data-tag');

			if(t.indexOf(n) > -1) t.splice(t.indexOf(n), 1);

			console.log(t);

			updateLabels(t);

			if(t.length > 0)
				$tags.val(t.join(','));
			else
				$tags.val('');
		}

		function addTagToList() {
			if($tags.val() == '')
				var t = [];
			else 
				var t = $tags.val().split(',');
			var n = $(this).attr('data-tag');

			if(t.indexOf(n) < 0) t.push(n);

			updateLabels(t);			

			if(t.length > 1)
				$tags.val(t.join(','));
			else
				$tags.val(t[0]);

			$productTagsResults.hide();
			$productTags.val('').focus();
		}

		function updateLabels(t) {
			$productTagsLabels.html('');
			for (var i = 0, l, ls; i < t.length; i++) {
				l = $("<span>");
				l.addClass('label').addClass('label-primary').addClass('label-lg');
					ls = $("<span>")
						.addClass('glyphicon glyphicon-tags');
				l.append(ls);
				l.append('&nbsp;' + t[i] + '&nbsp;');
					la = $("<a>")
						.attr('data-tag', t[i])
						.attr('href', 'javascript:void(0);')
						.html('<span class="glyphicon glyphicon-remove"></span>')
						.click(removeTagFromList);
				l.append(la);
				$productTagsLabels.append(l);
			};
		}


	});
}(jQuery));

function addProduct (id, btn) {
	$(btn).button('loading');
	$.post( "/cart/add/"+id, function(data){
		$("#cartAmount").html(data);
	});
}

function removeProduct (id) {
	$('tr#'+id).remove();
	$.post( "/cart/remove/"+id, function(data){
		if (data == "remove"){
			$("#cart").html("<h2>Winkelwagen</h2><h3>De winkelwagen is leeg</h3>");
			data = 0;
		}
		$("#cartAmount").html(data);
	});
}

function amountChange(id){
	if ($('tr#'+id+' .productAmount input').val() < 0 || !isNumber($('tr#'+id+' .productAmount input').val())){
		$('tr#'+id+' .productAmount input').val(0);
	}
	var price = $('tr#'+id+' .productPrice').html().replace("€", "");
	amount = $('tr#'+id+' .productAmount input').val();
	var total = parseFloat(Math.round((price*amount) * 100) / 100).toFixed(2);
	$('tr#'+id+' .productTotal').html("€"+total);

	$.post( "/cart/changeAmount/"+id+"/"+amount, function(data){
		$("#cartAmount").html(data);
	});

	getTotal();
}

function getTotal(){
	var excl = 0;
	var vat = 0;
	$('.product').each(function() {
		excl += parseFloat($(this).find(".productTotal").html().replace("€", ""));
		vat +=  parseFloat($(this).find(".productPrice").data("vat")) * parseFloat(($(this).find(".productAmount input").val())) ;
	});
	var total = excl+vat;
	$('#totalExcl').html("€"+excl.toFixed(2));
	$('#totalVat').html("€"+vat.toFixed(2));
	$('#total').html("€"+total.toFixed(2));
}

function chooseAdres(radio) {
	if ($(radio).val() == "new"){
		$('#checkout .existsAdres').hide();
		$('#checkout #newAdres').show();
	} else {
		$('#checkout .existsAdres').hide();
		$('#checkout #newAdres').hide();
		$('#checkout #'+$(radio).val()).show();
	}
}

function isNumber(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}

function removeOrder(id){
	$('#dismis #removeOrder').html($("#adminOrders #"+id).html());
	$('#dismis #removeOrder .actions').remove();
	$('#dismis #removeOrder a').replaceWith(id);
	$('#dismis #accept').attr("onclick", "removeOrderAccept("+id+")")
	$('#dismis').show();
}

function removeOrderClose(){
	$('#dismis').hide();
	$('#dismis #removeOrder').html("");
	$('#dismis #accept').removeAttr("onclick");
}

function removeOrderAccept(id){
	$("#adminOrders #"+id).remove();
	$.post( "/admin/orders/remove/"+id);
	removeOrderClose();
}

function removeCategory(id){
	$('#dismis #removeCategory').html("Categorie: "+$("#"+id+" span").html());
	$('#dismis #accept').attr("onclick", "removeCategoryAccept("+id+")")
	$('#dismis').show();
}

function removeCategoryClose(){
	$('#dismis').hide();
	$('#dismis #removeCategory').html("");
	$('#dismis #accept').removeAttr("onclick");
}

function removeCategoryAccept(id){
	$("#"+id).remove();
	$.post( "/admin/categories/remove/"+id);
	removeCategoryClose();
}

function changeParent(id){
	if ($("#"+id+".categoryItem").hasClass("active")){
		$(".categoryItem.active").removeClass("active");
		$("#hiddenCategory").removeAttr("value");
	} else {
		$(".categoryItem.active").removeClass("active");
		$("#"+id+".categoryItem").addClass("active");
		$("#hiddenCategory").val(id);
	}
}

function addCompare(object){
	if ($(object).prop( "checked") == true){ 
		if ($(".vergelijk:checked").length <= 3){
			var url = "/compare";
			$(".vergelijk:checked").each(function() {
				url += "/"+$(this).val();
			});
			$("#compareLink").attr("href", url);
		} else {
			$(object).prop("checked", false);
		}
	} else {
		var url = "/compare";
		$(".vergelijk:checked").each(function() {
			url += "/"+$(this).val();
		});
		$("#compareLink").attr("href", url);
	}
	$("#compareLink").html("Vergelijk ("+$(".vergelijk:checked").length+")")
	if ($(".vergelijk:checked").length >= 2){
		$("#compareLink").removeAttr('disabled');
	} else {
		$("#compareLink").attr('disabled', true);
	}
}