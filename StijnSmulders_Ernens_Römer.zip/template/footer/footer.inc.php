	
			<footer class="row">
				<div class="col-md-12">&copy; 2015 - Roel Ernens &amp; Stephan R&ouml;mer - Alle rechten voorbehouden.</div>
			</footer>

		</div>
	
		<script src="/js/jquery.min.js"></script>
	    <script src="/js/bootstrap.min.js"></script>
	    <script src="/js/functions.js"></script>
	</body>
</html>