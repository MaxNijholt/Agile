-- MySQL dump 10.13  Distrib 5.6.17, for osx10.6 (i386)
--
-- Host: localhost    Database: webshop
-- ------------------------------------------------------
-- Server version	5.5.40-0+wheezy1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address` (
  `adr_id` int(11) NOT NULL AUTO_INCREMENT,
  `adr_street1` varchar(45) NOT NULL,
  `adr_street2` varchar(45) DEFAULT NULL,
  `adr_zipcode` varchar(45) NOT NULL,
  `adr_city` varchar(45) NOT NULL,
  `adr_state` varchar(45) NOT NULL,
  `adr_country` char(2) NOT NULL,
  `adr_usr_id` int(11) NOT NULL,
  PRIMARY KEY (`adr_id`),
  KEY `fk_address_user_idx` (`adr_usr_id`),
  CONSTRAINT `fk_address_user` FOREIGN KEY (`adr_usr_id`) REFERENCES `user` (`usr_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` VALUES (9,'van Doorenstraat 22','','5481RD','Schijndel','Noord-Brabant','NL',45),(10,'AB','CD','EFGH12','GH','GH','NL',46),(11,'AB','CD','EFGH12','HENK','HENK','NL',47);
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(64) NOT NULL,
  `cat_parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`cat_id`),
  KEY `fk_category_category1_idx` (`cat_parent_id`),
  CONSTRAINT `fk_category_category1` FOREIGN KEY (`cat_parent_id`) REFERENCES `category` (`cat_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (12,'Games',NULL),(13,'Accesoires',NULL),(14,'Shooter',12),(15,'Racer',12),(16,'Sandbox',12),(17,'Controllers',13),(18,'Headsets',13);
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order` (
  `ord_id` int(11) NOT NULL AUTO_INCREMENT,
  `ord_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ord_status` varchar(32) NOT NULL DEFAULT 'Geplaatst',
  `ord_usr_id` int(11) NOT NULL,
  `ord_post_adr_id` int(11) NOT NULL,
  `ord_fact_adr_id` int(11) NOT NULL,
  PRIMARY KEY (`ord_id`),
  KEY `fk_order_user1_idx` (`ord_usr_id`),
  KEY `fk_order_address1_idx` (`ord_post_adr_id`),
  KEY `fk_order_address2_idx` (`ord_fact_adr_id`),
  CONSTRAINT `fk_order_user1` FOREIGN KEY (`ord_usr_id`) REFERENCES `user` (`usr_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_order_address1` FOREIGN KEY (`ord_post_adr_id`) REFERENCES `address` (`adr_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_order_address2` FOREIGN KEY (`ord_fact_adr_id`) REFERENCES `address` (`adr_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (25,'2015-02-27 22:39:00','Geplaats',45,9,9),(26,'2015-02-27 22:40:43','Geplaats',47,11,11);
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_has_product`
--

DROP TABLE IF EXISTS `order_has_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_has_product` (
  `ohp_ord_id` int(11) NOT NULL,
  `ohp_prd_id` int(11) NOT NULL,
  `ohp_amount` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ohp_ord_id`,`ohp_prd_id`),
  KEY `fk_order_has_product_product1_idx` (`ohp_prd_id`),
  KEY `fk_order_has_product_order1_idx` (`ohp_ord_id`),
  CONSTRAINT `fk_order_has_product_product1` FOREIGN KEY (`ohp_prd_id`) REFERENCES `product` (`prd_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_order_has_product_order1` FOREIGN KEY (`ohp_ord_id`) REFERENCES `order` (`ord_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_has_product`
--

LOCK TABLES `order_has_product` WRITE;
/*!40000 ALTER TABLE `order_has_product` DISABLE KEYS */;
INSERT INTO `order_has_product` VALUES (25,21,5),(25,25,2),(25,26,4),(26,19,1),(26,21,1),(26,22,1);
/*!40000 ALTER TABLE `order_has_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `prd_id` int(11) NOT NULL AUTO_INCREMENT,
  `prd_name` varchar(45) DEFAULT NULL,
  `prd_desc_short` varchar(512) DEFAULT NULL,
  `prd_desc_long` text,
  `prd_price` varchar(45) DEFAULT NULL,
  `prd_vat` int(11) DEFAULT NULL,
  `prd_cat_id` int(11) NOT NULL,
  PRIMARY KEY (`prd_id`),
  KEY `fk_product_category1_idx` (`prd_cat_id`),
  CONSTRAINT `fk_product_category1` FOREIGN KEY (`prd_cat_id`) REFERENCES `category` (`cat_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (17,'PS4 Controller','De controller voor de PS4','','80',21,17),(18,'XBOX One Controller','De controller voor de XBOX One','','80',21,17),(19,'PS4 Headset','De headset voor PS4','','29.99',21,18),(20,'XBOX Headset','De headset voor XBOX One','','29.99',21,18),(21,'GranTurismo','Racegame voor PS4','','69.99',21,15),(22,'Battlefield Hardline','Shooter voor PS4','','69.99',21,14),(23,'Minecraft','Sandbox game voor PC','','20',21,16),(24,'Forza 4','Racegame voor XBOX One','','59.99',21,15),(25,'SimCity 5','Sandbox building game for PC','','59.99',21,16),(26,'Call Of Duty','Shooter voor PC','','60.00',21,14);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_has_tag`
--

DROP TABLE IF EXISTS `product_has_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_has_tag` (
  `pht_prd_id` int(11) NOT NULL,
  `pht_tag` varchar(64) NOT NULL,
  PRIMARY KEY (`pht_prd_id`,`pht_tag`),
  KEY `fk_product_has_tag_tag1_idx` (`pht_tag`),
  KEY `fk_product_has_tag_product1_idx` (`pht_prd_id`),
  CONSTRAINT `fk_product_has_tag_product1` FOREIGN KEY (`pht_prd_id`) REFERENCES `product` (`prd_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_product_has_tag_tag1` FOREIGN KEY (`pht_tag`) REFERENCES `tag` (`tag`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_has_tag`
--

LOCK TABLES `product_has_tag` WRITE;
/*!40000 ALTER TABLE `product_has_tag` DISABLE KEYS */;
INSERT INTO `product_has_tag` VALUES (17,'controller'),(17,'game'),(17,'play'),(17,'playstation'),(17,'ps4'),(18,'controller'),(18,'one'),(18,'xbox'),(19,'headset'),(19,'play'),(19,'playstation'),(19,'ps4'),(20,'headset'),(20,'one'),(20,'xbox'),(21,'auto'),(21,'game'),(21,'gran'),(21,'racer'),(21,'turismo'),(22,'game'),(22,'playstation'),(22,'ps4'),(22,'shooter'),(23,'game'),(23,'pc'),(23,'playstation'),(23,'sandbox'),(23,'xbox'),(24,'game'),(24,'one'),(24,'racer'),(24,'xbox'),(25,'game'),(25,'pc'),(25,'sandbox'),(26,'game'),(26,'pc'),(26,'playstation'),(26,'shooter'),(26,'xbox');
/*!40000 ALTER TABLE `product_has_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag` (
  `tag` varchar(64) NOT NULL,
  `tag_metaphone` char(8) DEFAULT NULL,
  PRIMARY KEY (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES ('auto','AT'),('controller','KNTRLR'),('dicht',NULL),('game','KM'),('gran','KRN'),('headset','HTST'),('microfoon',NULL),('one','ON'),('pc','PK'),('play','PL'),('playstation','PLSTXN'),('ps4','PS'),('racer','RSR'),('sandbox','SNTBKS'),('shooter','XTR'),('turismo','TRSM'),('xbox','SBKS');
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `usr_id` int(11) NOT NULL AUTO_INCREMENT,
  `usr_mail` varchar(128) NOT NULL,
  `usr_pass` char(60) NOT NULL,
  `usr_tel` varchar(16) DEFAULT NULL,
  `usr_lastlogin` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `usr_admin` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`usr_id`),
  UNIQUE KEY `usr_mail_UNIQUE` (`usr_mail`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (45,'r@e.nl','$2y$10$qPWeTPMRAIguKJMkHBvL6Og4GUJ3ay/s0azDLzrJnW6LTSVS5bHNm','0123456789','2015-02-27 22:06:30',''),(46,'admin','$2y$10$VUwIqGpL5M8ggN/VCbdbe.kXEqIiR7u8XJM.iyQDRnadqsTtZnuCu','09876543210','2015-02-27 22:16:39',''),(47,'s@r.nl','$2y$10$fc/RKVyHf.nRDa.V097IRuiTdN/1BPoaQ/r.4sZWs93HTag1Pr9Y6','09876543212','2015-02-27 22:40:30','\0');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-02-27 23:42:04
