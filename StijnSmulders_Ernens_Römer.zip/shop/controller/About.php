<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace controller;
use core;

class About extends core\Controller {
	// /products
	public function index() {
		$this->load->view('About', array());
	}
}