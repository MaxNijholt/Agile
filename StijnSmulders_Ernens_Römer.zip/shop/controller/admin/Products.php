<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace controller\admin;
use model, tool;

class Products extends \core\Controller {

	/**
	 * Default action
	 */
	public function index($action = null, $id = null) {

		$response = array(
			'status' => null,
			'message' => null
		);

		if($_SERVER['REQUEST_METHOD'] == "POST") 
			$this->_handlePost($response['status'], $response['message'], $id);

		switch ($action) {
			case 'add':
				$response['product'] = $this->load->model('product');
				$this->load->view('admin/Products/Edit', $response);
				break;
			case 'edit':
				if($id == null) {
					header("Location: /admin/products/");
					return;
				}
				$response['product'] = $this->load->model('product', $id);
				$this->load->view('admin/Products/Edit', $response);
				break;
			case 'remove':
				$this->_handleRemove($id);
				break;
			default:
				$product = $this->load->model('product');
				$this->load->view('admin/Products', array(
					'products' => $product->loadAllProducts()
				));
				break;
		}
	}

	private function _handlePost(&$status, &$message, $id = null) {

		try {

			$c = new model\Category($_POST['category']);
			if($c->getID() == null)
				throw new \Exception("U dient een geldige categorie op te geven.");
				

			$p = new model\Product($id);
			$p->setName($_POST['name']);
			$p->setDescShort($_POST['desc_short']);
			$p->setDescLong($_POST['desc_long']);
			$p->setPrice(str_replace(",", ".", $_POST['price']));
			$p->setVAT($_POST['vat']);
			$p->setCat((int)$_POST['category']);

			$tarray = array();
			if(isset($_POST['tags']) && strlen($_POST['tags']) > 0) {
				$tags = explode(",", $_POST['tags']);
				foreach ($tags as $tag) {
					$t = new model\Tag();
					$t->setName($tag);
					$t->save();
					$tarray[$tag] = $t;
				}
			}

			$p->setTags($tarray);

			if($p->save()) {
				tool\Uploader::uploadImage($_SERVER['DOCUMENT_ROOT'] . '/media/products/' . $p->getID() . '.jpg');
				header("Location: /admin/products");
			} else {
				$status = 'danger';
				$message = 'Er is iets misgegaan met opslaan van het product. Probeert u het later nogmaals.';
			}
		} catch(\Exception $e) {
			$status = 'danger';
			$message = $e->getMessage();
			return false;
		}
	}

	private function _handleRemove($id = null) {
		$response = array(
			"success" => false
		);

		if($id != null) {
			$p = new model\Product($id);
			// Check if the product exists, if so: remove!
			if($p->getID() != null)
				$response['success'] = $p->remove();
		}

		echo json_encode($response);
	}
}