<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace controller\admin;
use model;

class Orders extends \core\Controller {

	/**
	 * Default action
	 */
	public function index($request=null, $id=null) {
		if (method_exists($this, $request)){
			$this->$request($id);
		} else {
			$orders = $this->load->model('order')->loadAll();
			$this->load->view('admin/Orders', array(
				'orders' => $orders,
				"formatter" => new \NumberFormatter('en_US', \NumberFormatter::CURRENCY)
			));
		}
	}

	private function edit($id){
		if($_SERVER['REQUEST_METHOD'] == "POST"){
			$orders = $this->load->model('order', $id);
			$orders->setStatus($_POST['status']);
			$orders->save();
			header("Location: /admin/orders");
		} else {
			$orders = $this->load->model('order', $id);
			$this->load->view('admin/Orders/Edit', array(
				'id' => $orders->getID(),
				'date' => $orders->getTimestamp(),
				'status' => $orders->getStatus(),
				'price' => $orders->getTotalVAT(),
				'usr' => $orders->getUser()->getMail(),
				'adres' =>  $orders->getPostAddress(),
				'products' => $orders->getProducts(),
				"formatter" => new \NumberFormatter('en_US', \NumberFormatter::CURRENCY)
			));
		}
	}

	private function remove($id) {
		$order = $this->load->model('order', $id);
		$order->remove();
	}
}