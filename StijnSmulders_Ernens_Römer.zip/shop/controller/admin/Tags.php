<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace controller\admin;
use model;

class Tags extends \core\Controller {

	/**
	 * Default action
	 */
	public function index() {
		$response = array(
			'success' => false,
			'result' => null
		);

		if(isset($_GET['name']) && strlen($_GET['name']) > 0) {
			$tag = new model\Tag();
			$response['success'] = true;
			$response['result'] = $tag->loadTagsBySearch($_GET['name']);
		}

		echo json_encode($response);
	}

}
