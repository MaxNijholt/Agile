<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace controller\admin;
use model;

class Categories extends \core\Controller {

	/**
	 * Default action
	 */
	public function index($request=null, $id=null) {
		if (method_exists($this, $request)){
			$this->$request($id);
		} else {
			$categorys = $this->load->model('category');
			$this->load->view('admin/Categories', array(
				'categorys' => $categorys->loadParents()
			));
		}
	}

	private function add(){
		if($_SERVER['REQUEST_METHOD'] == "POST"){
			$category = $this->load->model('category', $id);
			$category->setName($_POST['name']);
			if (isset($_POST['parentCategory']) && strlen($_POST['parentCategory']) > 0){
				$category->setParent($_POST['parentCategory']);
			}
			$category->save();
			header("Location: /admin/categories");
		} else {
			$category = $this->load->model('category');
			$this->load->view('admin/Categories/Edit', array(
				'children' => array(),
				'parents' => $category->loadParents()
			));
		}
	}

	private function edit($id){
		if($_SERVER['REQUEST_METHOD'] == "POST"){
			$category = $this->load->model('category', $id);
			$category->setName($_POST['name']);
			if (isset($_POST['parentCategory']) && strlen($_POST['parentCategory']) > 0){
				$category->setParent($_POST['parentCategory']);
			} else {
				$category->setParent(null);
			}
			$category->save();
			header("Location: /admin/categories");
		} else {
			$category = $this->load->model('category', $id);
			$this->load->view('admin/Categories/Edit', array(
				'id' => $category->getID(),
				'name' => $category->getName(),
				'children' => $category->getChildren(),
				'parent' => ($category->getParent() != false) ? $category->getParent()->getID() : false,
				'parents' => $category->loadParents()
			));
		}
	}

	private function remove($id) {
		$order = $this->load->model('category', $id);
		print_r($order->remove());
	}

	/**
	 * Method to search for a category
	 */
	public function search() {
		$response = array(
			'success' => false,
			'result' => null
		);

		if(isset($_GET['name']) && strlen($_GET['name']) > 0) {
			$c = new model\Category();
			$response['success'] = true;
			$response['result'] = $c->loadByName($_GET['name']);
		}


		echo json_encode($response);
	}
}