<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace controller;
use core, model;

class Order extends core\Controller {
	
	public function index($id = null) {
		if(($user = $this->_settings->getUser()) === false) {
			header("Location: /home");
		} else if ($id != null && array_key_exists($id, $user->getOrders())) {
			$order = $user->getOrders()[$id];
			$this->load->view('Orderdetail', array(
				"id" => $order->getID(),
				"timestamp" => $order->getTimestamp(),
				"adres" => $order->getPostAddress(),
				"products" => $order->getProducts(),
				"excl" => $order->getTotal(),
				"btw" => $order->getVAT(),
				"total" => $order->getTotalVAT(),
				"formatter" => new \NumberFormatter('en_US', \NumberFormatter::CURRENCY)
			));	
		} else {
			$orders = $user->getOrders();
			$this->load->view('Order', array(
				"orders" => $orders,
				"formatter" => new \NumberFormatter('en_US', \NumberFormatter::CURRENCY)
			));	
		}
	}

	public function add() {
		if($_SERVER['REQUEST_METHOD'] == "POST") {
			$order = new model\Order();
			$cart = unserialize($_SESSION['cart']);
			if ($_POST['adres'] == "new"){
				$adres = new model\Address();
				$adres->setStreet1($_POST['street1']);
				$adres->setStreet2($_POST['street2']);
				$adres->setZipcode($_POST['zipcode']);
				$adres->setCity($_POST['city']);
				$adres->setState($_POST['state']);
				$adres->setCountry($_POST['country']);
				$adres->setUser($this->_settings->getUser());
				$adres->save();
			} else {
				$adres = new model\Address($_POST['adres']);
			}
			$order->setTimestamp(date("Y-m-d H:i:s"));
			$order->setStatus("Geplaats");
			$order->setUsr_id($this->_settings->getUser());
			$order->setPostAddress($adres);
			$order->setFactAddress($adres);
			foreach ($cart->getProduct() as $key => $product) {
				$order->addProducts($product[0], $key);
			}
			$order->save();
			unset($_SESSION['cart']);
			header("Location: /order/".$order->getID());
		} else {
			header("Location: /home");
		}
	}
}