<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace controller;
use core;

class Search extends core\Controller {

	/**
	 * Main Action
	 * @param  String $query The search query
	 */
	public function index() {
		if(isset($_GET['query'])) {
			$query = urldecode($_GET['query']);
			$product = $this->load->model('product');
			$this->load->view('Search', array(
				'products' => $product->loadProductsBySearch($query),
				'formatter' => new \NumberFormatter('en_US', \NumberFormatter::CURRENCY)
			));
		} else {
			$this->load->view('Search', array(
				'products' => array()
			));
		}
	}
}