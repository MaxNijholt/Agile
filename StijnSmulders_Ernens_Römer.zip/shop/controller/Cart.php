<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace controller;
use core;

class Cart extends core\Controller {
	
	public function index() {
		$cart = (isset($_SESSION['cart'])) ? unserialize($_SESSION['cart']) : $this->load->model('cart');
		$this->load->view('cart', array(
			"products" => $cart->getProduct(),
			"excl" => $cart->getTotal(),
			"btw" => $cart->getVAT(),
			"total" => $cart->getTotalVAT(),
			"formatter" => new \NumberFormatter('en_US', \NumberFormatter::CURRENCY)
		));
	}

	public function add($id) {
		$product = $this->load->model('product', $id);
		$cart = (isset($_SESSION['cart'])) ? unserialize($_SESSION['cart']) : $this->load->model('cart');
		$cart->addProduct($product->getID(), $product->getName(), $product->getPrice(), $product->getVat());
		$_SESSION['cart'] = serialize($cart);
		echo $cart->countItems();
	}

	public function remove($id) {
		$cart = unserialize($_SESSION['cart']);
		$cart->removeProduct($id);
		$_SESSION['cart'] = serialize($cart);
		echo (count($cart->getProduct()) > 0) ? $cart->countItems() : "remove";
	}

	public function changeAmount($id, $amount) {
		$cart = unserialize($_SESSION['cart']);
		$cart->changeAmount($id, $amount);
		$_SESSION['cart'] = serialize($cart);
		echo $cart->countItems();
	}

	public function checkout($page = null){
		if (isset($_SESSION['cart']) && unserialize($_SESSION['cart'])->countItems() > 0) {
			$cart = unserialize($_SESSION['cart']);
			if(($user = $this->_settings->getUser()) != false) {
				$this->load->view('Checkout', array(
					"address" => $user->getAddress(),
					"products" => $cart->getProduct(),
					"excl" => $cart->getTotal(),
					"btw" => $cart->getVAT(),
					"total" => $cart->getTotalVAT(),
					"formatter" => new \NumberFormatter('en_US', \NumberFormatter::CURRENCY)
				));
			} else {
				if ($page == "register"){
					$c = new Register();
					$c->index("/cart/checkout/register");
				} else {
					$c = new Login();
					$c->index("/cart/checkout", "/cart/checkout/register");
				} 
			}
		} else {
			header("Location: /cart");
		}
	}
}