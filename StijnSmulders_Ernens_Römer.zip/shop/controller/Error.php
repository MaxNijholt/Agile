<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace controller;
use core;

class Error extends core\Controller {
	public function index() {
		$product = $this->load->model('product');
		$this->load->view('Error', array(
			"products" => $product->loadRandomProducts(3),
			"formatter" => new \NumberFormatter('en_US', \NumberFormatter::CURRENCY)
		));
	}
}