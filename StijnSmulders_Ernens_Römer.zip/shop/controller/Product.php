<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace controller;
use core;

class Product extends core\Controller {
	
	public function index($id=null) {
		if ($id == null){
			header("Location: /home");
		} else {
			$product = $this->load->model('product', $id);
			if ($product->getID() != null){
				$cat = $product->getCat();
				$breadcrumb = array();
				if (($par = $cat->getParent()) != false) {
					$breadcrumb[] = array("/category/".$par->getID(), $par->getName());
					$breadcrumb[] = array("/category/".$cat->getID(), $cat->getName());
				} else {
					$breadcrumb[] = array("/category/".$cat->getID(), $cat->getName());
				}
				$breadcrumb[] = array("/product/".$product->getID(), $product->getName());
				$this->load->view('product', array(
					"similiar" => $product->loadSimiliarProducts(4),
					"name" => $product->getName(),
					"desc" => $product->getDesc('long'),
					"id" => $product->getID(),
					"price" => $product->getPrice(),
					"tags" => $product->getTags(),
					"breadcrumb" => $breadcrumb,
					"formatter" => new \NumberFormatter('en_US', \NumberFormatter::CURRENCY)
				));
			} else {
				$this->load->view('product', array(
					"name" => "Product niet leverbaar",
					"desc" => "Onze excuses, het product is niet (meer) leverbaar.",
					"breadcrumb" => array(array("/product", "product"))
				));
			}
		}
	}
}