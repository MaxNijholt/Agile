<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace controller;
use core;

class Home extends core\Controller {
	public function index() {
		$category = $this->load->model('category');
		$product = $this->load->model('product');
		$this->load->view('Home', array(
			"categorys" => $category->loadParents(),
			"products" => $product->loadRandomProducts(9),
			"formatter" => new \NumberFormatter('en_US', \NumberFormatter::CURRENCY)
		));
	}
}