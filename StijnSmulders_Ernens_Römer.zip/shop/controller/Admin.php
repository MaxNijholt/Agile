<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace controller;
use core, controller\admin;

class Admin extends core\Controller {
	// /products
	public function index($page = null, $action = null, $id = null) {
		if(false === ($user = $this->_settings->getUser())) {
			header("Location: /home");
			return;
		}

		if(!$user->isAdmin()) {
			header("Location: /home");
			return;
		}

		switch ($page) {
			case 'products':
				$c = new admin\Products();
				$c->index($action, $id);
				break;
			case 'orders':
				$c = new admin\Orders();
				$c->index($action, $id);
				break;
			case 'categories':
				$o = new admin\Categories();
				$o->index($action, $id);
				break;
			case 'tags':
				$o = new admin\Tags();
				$o->index();
				break;
			default:
				$this->load->view('admin');
				break;
		}
	}
}