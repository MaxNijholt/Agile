<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace controller;
use core;

class Compare extends core\Controller {
	// /products
	public function index($id1=null, $id2=null, $id3=null) {
		if ($id1==null || $id2==null){
			header("Location: /home");
		} else {
			$this->load->view('Compare', array(
				'product1' => $this->load->model("Product", $id1),
				'product2' => $this->load->model("Product", $id2),
				'product3' => ($id3!=null) ? $this->load->model("Product", $id3) : false
			));
		}
	}
}