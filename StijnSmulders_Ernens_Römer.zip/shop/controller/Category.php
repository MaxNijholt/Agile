<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace controller;
use core;

class Category extends core\Controller {
	
	public function index($cat=null) {
		if ($cat == null){
			header("Location: /Home");
		} else {
			$category = $this->load->model('category', $cat);
			$products = $category->getProducts();
			foreach ($category->getChildren() as $child) {
				$products = array_merge($products, $child->getProducts());
			}
		}

		$breadcrumb = array();
		if (($par = $category->getParent()) != false) {
			$breadcrumb[] = array("/category/".$par->getID(), $par->getName());
			$breadcrumb[] = array("/category/".$category->getID(), $category->getName());
		} else {
			$breadcrumb[] = array("/category/".$category->getID(), $category->getName());
		}

		$this->load->view('Home', array(
			"categorys" => $category->loadParents(),
			"products" => $products,
			"breadcrumb" => $breadcrumb,
			"formatter" => new \NumberFormatter('en_US', \NumberFormatter::CURRENCY)
		));
	}
}