<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace model;
use core;

/**
 * Specifies a certain product
 */
class Order extends core\Model {

	/* Private Variables */
	private $_id = null;
	private $_timestamp = null;
	private $_status = null;
	private $_usr_id = null;
	private $_post_adr = null;
	private $_fact_adr = null;
	private $_products = array();

	/**
	 * Method to get the id of this order
	 * @return Integer The id
	 */
	public function getID() {
		return $this->_id;
	}

	/**
	 * Method to get the timestamp of this order
	 * @return String The timestamp
	 */
	public function getTimestamp() {
		return date("d-m-Y H:i", strtotime($this->_timestamp));
	}

	/**
	 * Method to get the timestamp of this order
	 * @return String The timestamp
	 */
	public function getStatus() {
		return $this->_status;
	}

	/**
	 * Method to get the usr_id of this order
	 * @return Integer The usr_id
	 */
	public function getUser() {
		return new User($this->_usr_id);
	}

	/**
	 * Method to get the post address of this order
	 * @return Address The post_adr_id
	 */
	public function getPostAddress() {
		return $this->_post_adr;
	}

	/**
	 * Method to get the fact address of this order
	 * @return Address The fact_adr_id
	 */
	public function getFactAddress() {
		return $this->_fact_adr;
	}

	/**
	 * Method to get the products of this order
	 * @return Array The products
	 */
	public function getProducts() {
		return $this->_products;
	}

	/**
	 * Method to get the total price of the cart
	 * @return Float       The price excl. VAT
	 */
	public function getTotal() {
		$o = 0;
		foreach ($this->_products as $id => $parr) 
			$o += $parr[1]->getPrice()*$parr[0];
		return $o;
	}

	/**
	 * Method to get the total VAT amount of the products in the cart
	 * @return Float The amount of VAT
	 */
	public function getVAT() {
		$o = 0;
		foreach ($this->_products as $id => $parr) 
			$o += ($parr[1]->getPrice() * ($parr[1]->getVat() / 100) * $parr[0]);
		return $o;
	}

	/**
	 * Method to get the total amount including taxes (VAT)
	 * @return Float The total amount (price)
	 */
	public function getTotalVAT() {
		return ($this->getTotal() + $this->getVAT());
	}

	/**
	 * Method to set the id of this order
	 * @param Integer $value The id
	 */
	public function setId($value) {
		$this->_id = $value;
	}

	/**
	 * Method to set the timestamp of this order
	 * @param String $value The timestamp
	 */
	public function setTimestamp($value) {
		$this->_timestamp = $value;
	}

	/**
	 * Method to set the timestamp of this order
	 * @param String $value The timestamp
	 */
	public function setStatus($value) {
		$this->_status = $value;
	}

	/**
	 * Method to set the usr_id of this order
	 * @param Integer $value The usr_id
	 */
	public function setUsr_id($value) {
		$this->_usr_id = $value->getID();
	}

	/**
	 * Method to set the post address of this order
	 * @param Address $value The post_adr_id
	 */
	public function setPostAddress($value) {
		$this->_post_adr = $value;
	}

	/**
	 * Method to set the fact address of this order
	 * @param Address $value The fact_adr_id
	 */
	public function setFactAddress($value) {
		$this->_fact_adr = $value;
	}

	/**
	 * Method to set the products of this order
	 * @param Array $value The products
	 */
	public function addProducts($amount, $id) {
		$this->_products[$id] = array($amount, new Product($id));
	}

	/**
	 * Method to construct a new order
	 */
	public function __construct($id = null) {
		parent::__construct();
		if($id != null) $this->load($id);
	}

	/**
	 * Method to load the values of this order from the database
	 */
	public function load($id = null) {
		// Load from the database
		if(false !== ($order = $this->_db->select("SELECT * FROM `order` WHERE ord_id = :id;", array(':id' => $id)))) {
			$this->_id 			= $order['ord_id'];
			$this->_timestamp 	= $order['ord_timestamp'];
			$this->_status		= $order['ord_status'];
			$this->_usr_id 		= $order['ord_usr_id'];
			$this->_post_adr 	= new Address($order['ord_post_adr_id']);
			$this->_fact_adr 	= new Address($order['ord_fact_adr_id']);

			$this->_products = array();
			if(false !== ($products = $this->_db->select("SELECT ohp_prd_id, ohp_amount FROM order_has_product WHERE ohp_ord_id = :id;", array(':id' => $this->_id), true))) {
				foreach ($products as $product) {
					$p = new Product($product['ohp_prd_id']);
					
					$this->_products[$product['ohp_prd_id']] = array($product['ohp_amount'], $p);
				}
			}
		}
	}

	/**
	 * Method to load the values of this order from the database
	 */
	public function loadAll($id = null) {
		$allOrders = array();
		if(false !== ($orders = $this->_db->select("SELECT * FROM `order`;", array(':id' => $id), true))) {
			foreach ($orders as $order) {
				$allOrders[] = new Order($order['ord_id']);
			}
		}
		return $allOrders;
	}

	/**
	 * Method to remove the order
	 */
	public function remove() {
		$response = $this->_db->command("DELETE FROM order_has_product WHERE ohp_ord_id = :id;", array(':id' => $this->_id));
		$response = $this->_db->command("DELETE FROM `order` WHERE ord_id = :id;", array(':id' => $this->_id));
		return $response;
	}

	/**
	 * Method to save the values of this product to the database
	 */
	public function save() {
		// Insert, but when already in the database, update
		$isInserted = ($this->_id == null) ? true : false;
		$response = $this->_db->command("INSERT INTO `order` (
			`ord_id`,
			`ord_timestamp`,
			`ord_status`,
			`ord_usr_id`,
			`ord_post_adr_id`,
			`ord_fact_adr_id`
		) VALUES (
			:id,
			:timestamp,
			:status,
			:usr_id,
			:post_adr,
			:fact_adr
		) ON DUPLICATE KEY UPDATE
			`ord_timestamp` = VALUES(`ord_timestamp`),
			`ord_status` = VALUES(`ord_status`),
			`ord_usr_id` = VALUES(`ord_usr_id`),
			`ord_post_adr_id` = VALUES(`ord_post_adr_id`),
			`ord_fact_adr_id` = VALUES(`ord_fact_adr_id`)
		;", array(
			':id' 			=> $this->_id,
			':timestamp' 	=> $this->_timestamp,
			':status' 		=> $this->_status,
			':usr_id' 		=> $this->_usr_id,
			':post_adr' 	=> $this->_post_adr->getID(),
			':fact_adr' 	=> $this->_fact_adr->getID()
		), true);

		if($isInserted) $this->_id = $response['lastInsertId'];

		// Update Tag's and dependencies with this product in the database
		if(true == $this->_db->command("DELETE FROM order_has_product WHERE ohp_ord_id = :id;", array(':id' => $this->_id))) {
			foreach ($this->_products as $product) {
				$this->_db->command("INSERT INTO order_has_product VALUES (:id, :prd, :amount);", array(
					':id' => $this->_id,
					':prd' => $product[1]->getID(),
					'amount' => $product[0]
				));
			}
		}
	}
}