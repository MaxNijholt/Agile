<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace model;
use core;

/**
 * Specifies a certain product
 */
class Product extends core\Model {

	/* Private variables */
	private $_id = null;
	private $_name = null;
	private $_desc_short = null;
	private $_desc_long = null;
	private $_price = null;
	private $_vat = null;
	private $_cat_id = null;
	private $_tags = array();

	/* Encapsulation */

	/**
	 * Method to get the id of this product
	 * @return Integer The ID
	 */
	public function getID() {
		return $this->_id;
	}

	/**
	 * Method to get the name of this product
	 * @return String The name
	 */
	public function getName() {
		return $this->_name;
	}

	/**
	 * Method to get the description of this product
	 * @param  String $type The type of description (short|long)
	 * @return String       The description
	 */
	public function getDesc($type = 'short') {
		switch ($type) {
			case 'long':
				return $this->_desc_long;
				break;
			default:
				return $this->_desc_short;
				break;
		}
	}

	/**
	 * Method to get the price of this product
	 * @return Float The price
	 */
	public function getPrice() {
		return $this->_price;
	}

	/**
	 * Method to get the VAT percentage of this product
	 * @return Integer The VAT percentage
	 */
	public function getVat() {
		return $this->_vat;
	}

	/**
	 * Method to get the Category of this product
	 * @return Category The category
	 */
	public function getCat() {
		return new Category($this->_cat_id);
	}

	/**
	 * Method to get all the tags this product has
	 * @return Array The array of Tags
	 */
	public function getTags() {
		return $this->_tags;
	}

	/**
	 * Method to set the ID of this product
	 * @param Integer $value The ID
	 */
	public function setID($value) {
		if(false === ($value = $this->checkField($value, 'integer', 1)))
			throw new \Exception("Geef een numeriek ID op.");

		$this->_id = $value;
	}

	/**
	 * Method to set the name of this product
	 * @param String $value The name
	 */
	public function setName($value) {
		if(false === ($value = $this->checkField($value, 'string', 0, 64)))
			throw new \Exception("Geef een geldige productnaam op.");

		$this->_name = $value;
	}

	/**
	 * Method to set the short description of this product
	 * @param String $value The short description
	 */
	public function setDescShort($value) {
		if(false === ($value = $this->checkField($value, 'string', 0, 200)))
			throw new \Exception("Geef een geldige korte beschrijving op, niet langer dan 200 tekens.");
			
		$this->_desc_short = $value;
	}

	/**
	 * Method to set the long description of this product
	 * @param String $value The long description
	 */
	public function setDescLong($value) {
		if(false === ($value = $this->checkField($value, 'string', 0)))
			throw new \Exception("Geef een geldige lange beschrijving op.");

		$this->_desc_long = $value;
	}

	/**
	 * Method to set the price of this product
	 * @param Float $value The price
	 */
	public function setPrice($value) {
		if(false === ($value = $this->checkField($value, 'float', 0.01)))
			throw new \Exception("Geef een geldige prijs op.");

		$this->_price = $value;
	}

	/**
	 * Method to set the VAT percentage of this product
	 * @param Integer $value The VAT percentage
	 */
	public function setVAT($value) {
		if(false === ($value = $this->checkField($value, 'float', 0, 100)))
			throw new \Exception("Geef een geldig BTW percentage op, gebruik 0 voor geen BTW.");

		$this->_vat = $value;
	}

	/**
	 * Method to set the category of this product
	 * @param Category $value The category
	 */
	public function setCat($value) {
		if(false === ($value = $this->checkField($value, 'integer')))
			throw new \Exception("Geef een geldig categorie ID op.");

		$this->_cat_id = $value;
	}

	/**
	 * Method to add a tag to this product
	 * @param Tag $value The tag to be added
	 */
	public function addTag($value) {
		if(!isset($this->_tags[$value->getName()]))
			$this->_tags[$value->getName()] = $value;
	}

	/**
	 * Method to remove a tag from this product
	 * @param  Tag $value The tag to be removed
	 */
	public function removeTag($value) {
		if(isset($this->_tags[$value->getName()]))
			unset($this->_tags[$value->getName()]);
	}

	/**
	 * Method to just throw in an array of tags
	 * @param Array $value The array of Tags
	 */
	public function setTags($value) {
		$this->_tags = $value;
	}

	/**
	 * Method to construct a new product
	 */
	public function __construct($id = null) {
		parent::__construct();
		if($id != null) $this->load($id);
	}

	/**
	 * Method to load the values of this product from the database
	 */
	public function load($id = null) {
		// Load from the database
		if(false !== ($product = $this->_db->select("SELECT * FROM product WHERE prd_id = :id;", array(':id' => $id)))) {
			$this->_id 			= $product['prd_id'];
			$this->_name 		= $product['prd_name'];
			$this->_desc_short 	= $product['prd_desc_short'];
			$this->_desc_long 	= $product['prd_desc_long'];
			$this->_price 		= $product['prd_price'];
			$this->_vat 		= $product['prd_vat'];
			$this->_cat_id 		= $product['prd_cat_id'];

			$this->_tags = array();
			if(false !== ($tags = $this->_db->select("SELECT tag, tag_metaphone FROM product_has_tag JOIN tag ON pht_tag = tag WHERE pht_prd_id = :id;", array(':id' => $this->_id), true))) {
				foreach ($tags as $key => $tag) {
					$t = new Tag();
					$t->setName($tag['tag']);
					$t->setMetaphone($tag['tag_metaphone']);
					// Append to the array of tags
					$this->_tags[$t->getName()] = $t;
				}
			}
		}
	}

	/**
	 * Method to load similiar products based on tags
	 * @param  Integer $limit The maximum number of products that should be loaded
	 * @return Array The array of similia products
	 */
	public function loadSimiliarProducts($limit = 3) {
		$response = array();
		if(count($this->_tags) > 0) {

			$tagstring = "";
			foreach ($this->_tags as $name => $tag)
				$tagstring .= " OR pht_tag = '" . $name . "'";
			$tagstring = substr($tagstring, 4);

			if(false !== ($products = $this->_db->select("SELECT prd_id, (
					SELECT 
						COUNT(*)
					FROM 
						product_has_tag 
					WHERE pht_prd_id = prd_id 
						AND ({$tagstring})
					) as num
				FROM 
					product
				WHERE
					prd_id != :id
				ORDER BY num DESC LIMIT $limit;
			", array(
				':id' => $this->_id
			)))) {
				foreach ($products as $key => $product) {
					$p = new Product($product['prd_id']);
					$response[$p->getName()] = $p;	
				}
			}
		}

		return $response;
	}

	/**
	 * Method to load random products
	 * @return Array The array of random products
	 */
	public function loadRandomProducts($limit = 9) {
		$rand = array();
		if(false !== ($products = $this->_db->select("SELECT * FROM product ORDER BY rand() LIMIT $limit;", array(), true))) {
			foreach ($products as $product) {
				$rand[] = new Product($product['prd_id']);
			}
		}
		return $rand;
	}

	/**
	 * Method to load all products available
	 * @return Array The array of products
	 */
	public function loadAllProducts() {
		$array = array();
		if(false !== ($products = $this->_db->select("SELECT * FROM product;", array(), true))) {
			foreach ($products as $p) {
				$array[] = new Product($p['prd_id']);
			}
		}
		return $array;
	}

	/**
	 * Method to load products by a search string
	 * @param  String $query The string to search for
	 * @return Array         The array of products
	 */
	public function loadProductsBySearch($query) {
		$query = "%$query%";
		$metaphone = metaphone($query);

		$array = array();
		if(false !== ($products = $this->_db->select("
			SELECT
				prd_id 
			FROM 
				product 
			WHERE 
				(prd_desc_short LIKE :query 
			  OR prd_desc_short LIKE :query 
			  OR prd_name LIKE :query);
		", array(':query' => $query), true))
		&& false !== ($products_by_tag = $this->_db->select("
			SELECT 
				prd_id 
			FROM 
				product 
			JOIN 
				product_has_tag ON prd_id = pht_prd_id
			JOIN
				tag ON pht_tag = tag
			WHERE 
				(tag LIKE :query
			  OR tag_metaphone = :metaphone);
		", array(':query' => $query, ':metaphone' => $metaphone), true))) {
			$got = array();
			foreach ($products as $p) {
				$got[] = $p['prd_id'];
				$array[] = new Product($p['prd_id']);
			}

			foreach ($products_by_tag as $p) {
				if(!in_array($p['prd_id'], $got))
					$array[] = new Product($p['prd_id']);
			}
		}
		return $array;
	}

	/**
	 * Method to save the values of this product to the database
	 */
	public function save() {
		// Insert, but when already in the database, update
		$isInserted = ($this->_id == null) ? true : false;
		$response = $this->_db->command("INSERT INTO `product` (
			`prd_id`,
			`prd_name`,
			`prd_desc_short`,
			`prd_desc_long`,
			`prd_price`,
			`prd_vat`,
			`prd_cat_id`
		) VALUES (
			:id,
			:name,
			:desc_short,
			:desc_long,
			:price,
			:vat,
			:cat_id
		) ON DUPLICATE KEY UPDATE
			`prd_name` = VALUES(`prd_name`),
			`prd_desc_short` = VALUES(`prd_desc_short`),
			`prd_desc_long` = VALUES(`prd_desc_long`),
			`prd_price` = VALUES(`prd_price`),
			`prd_vat` = VALUES(`prd_vat`),
			`prd_cat_id` = VALUES(`prd_cat_id`)
		;", array(
			':id' 			=> $this->_id,
			':name' 		=> $this->_name,
			':desc_short' 	=> $this->_desc_short,
			':desc_long' 	=> $this->_desc_long,
			':price' 		=> $this->_price,
			':vat' 			=> $this->_vat,
			':cat_id' 		=> $this->_cat_id
		), true);

		if($isInserted) $this->_id = $response['lastInsertId'];

		// Update Tag's and dependencies with this product in the database
		if(true == $this->_db->command("DELETE FROM product_has_tag WHERE pht_prd_id = :id;", array(':id' => $this->_id))) {
			foreach ($this->_tags as $key => $tag) {
				$tag->save();
				$this->_db->command("INSERT INTO product_has_tag VALUES (:id, :tag);", array(
					':id' => $this->_id,
					':tag' => $tag->getName()
				));
			}

			return true;
		}

		return false;
	}


	public function remove() {
		if($this->_id != null) {
			if($this->_db->command("DELETE FROM product_has_tag WHERE pht_prd_id = :id;", array(':id' => $this->_id))
			&& $this->_db->command("DELETE FROM product WHERE prd_id = :id;", array(':id' => $this->_id))) {
				return true;
			}
		}

		return false;
	}
}