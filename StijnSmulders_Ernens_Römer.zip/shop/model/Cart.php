<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace model;

class Cart {

	/* Private Variables */
	// array(
	// 		[id]	=>		array( [amount] , [product] ),
	// 		[id]	=>		array( [amount] , [product] )
	// );
	private $_products = array();

	/**
	 * Method to get all the products stored in the cart
	 * @return [type] [description]
	 */
	public function getProduct() {
		return $this->_products;
	}

	/**
	 * Method to add a product to the cart
	 * @param Integer $obj Mixed, product or product ID
	 */
	public function addProduct($id, $name, $price, $vat) {
		if(isset($this->_products[$id]))
			$this->_products[$id][0]++;
		else
			$this->_products[$id] = array(1, array("name" => $name, "price" => $price, "vat" => $vat));
	}

	/**
	 * Method to change the amount of a product stored in the cart
	 * @param  Integer $id     The id to identify a product
	 * @param  Integer $amount The amount which will be set
	 */
	public function changeProductAmount($id, $amount) {
		if(isset($this->_products[$id]))
			$this->_products[$id][0] = $amount;
	}

	public function changeAmount($id, $amount) {
		if(isset($this->_products[$id])) {
			$this->_products[$id][0] = $amount;
		}
	}

	/**
	 * Method to remove a product from the cart
	 * @param  Integer $id The id of the product to be removed
	 */
	public function removeProduct($id) {
		if(isset($this->_products[$id])) {
			unset($this->_products[$id]);
		}
	}

	/**
	 * Method to count all stored items in the cart
	 * @return Integer The amount of items in the cart
	 */
	public function countItems() {
		$o = 0;
		foreach ($this->_products as $id => $parr) 
			$o += $parr[0];
		return $o;
	}

	/**
	 * Method to get the total price of the cart
	 * @return Float       The price excl. VAT
	 */
	public function getTotal() {
		$o = 0;
		foreach ($this->_products as $id => $parr) 
			$o += $parr[1]['price']*$parr[0];
		return $o;
	}

	/**
	 * Method to get the total VAT amount of the products in the cart
	 * @return Float The amount of VAT
	 */
	public function getVAT() {
		$o = 0;
		foreach ($this->_products as $id => $parr) 
			$o += ($parr[1]['price'] * ($parr[1]['vat'] / 100) * $parr[0]);
		return $o;
	}

	/**
	 * Method to get the total amount including taxes (VAT)
	 * @return Float The total amount (price)
	 */
	public function getTotalVAT() {
		return ($this->getTotal() + $this->getVAT());
	}
}