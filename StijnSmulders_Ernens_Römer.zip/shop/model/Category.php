<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace model;
use core;

/**
 * Specifies a certain product
 */
class Category extends core\Model {

	/* Private variables */
	private $_id = null;
	private $_name = null;
	private $_parent_id = null;
	private $_children = array();

	/**
	 * Method to get the id of this category
	 * @return Integer The ID
	 */
	public function getID() {
		return $this->_id;
	}

	/**
	 * Method to get the name of this category
	 * @return String The name
	 */
	public function getName() {
		return $this->_name;
	}

	/**
	 * Method to get the parent of this category
	 * @return Categorie The parent
	 */
	public function getParent() {
		return ($this->_parent_id != null && strlen($this->_parent_id) > 0) ? new Category($this->_parent_id) : false;
	}

	/**
	 * Method to get the children of this category
	 * @return Array The children
	 */
	public function getChildren() {
		return $this->_children;
	}

	/**
	 * Method to get the products of this category
	 * @return Array The products
	 */
	public function getProducts() {
		$allproducts = array();
		if(false !== ($products = $this->_db->select("SELECT * FROM product WHERE prd_cat_id = :id;", array(':id' => $this->_id), true))) {
			foreach ($products as $product) {
				$prd = new Product($product['prd_id']);
				$allproducts[] = $prd;
			}
		}
		return $allproducts;
	}

	/**
	 * Method to set the ID of this category
	 * @param Integer $value The ID
	 */
	public function setID($value) {
		$this->_id = $value;
	}

	/**
	 * Method to set the name of this category
	 * @param String $value The name
	 */
	public function setName($value) {
		$this->_name = $value;
	}

	/**
	 * Method to set the parent of this category
	 * @param Categorie $value The parent
	 */
	public function setParent($value) {
		$this->_parent_id = $value;
	}

	/**
	 * Method to set the children of this category
	 * @param Array $value The children
	 */
	public function setChildren($value) {
		$this->_children = $value;
	}

	/**
	 * Method to construct a new category
	 */
	public function __construct($id = null) {
		parent::__construct();
		if($id != null) $this->load($id);
	}

	/**
	 * Method to load the values of this product from the database
	 */
	public function load($id = null) {
		// Load from the database
		if(false !== ($category = $this->_db->select("SELECT * FROM category WHERE cat_id = :id;", array(':id' => $id)))) {
			$this->_id 			= $category['cat_id'];
			$this->_name 		= $category['cat_name'];
			$this->_parent_id 	= $category['cat_parent_id'];
			$this->_children = array();
			if(false !== ($categorys = $this->_db->select("SELECT * FROM category WHERE cat_parent_id = :id;", array(':id' => $this->_id), true))) {
				foreach ($categorys as $category) {
					$cat = new Category($category['cat_id']);
					$this->_children[] = $cat;
				}
			}
		}
	}

	/**
	 * Method to load the parent category's
	 * @return String The parent category's
	 */
	public function loadParents(){
		$parents = array();
		if(false !== ($categories = $this->_db->select("SELECT * FROM category WHERE cat_parent_id IS NULL;", array(), true))) {
			foreach ($categories as $category) {
				$parents[] = new Category($category['cat_id']);
			}
		}
		return $parents;
	}

	/**
	 * Method to search for categories using a name
	 * @param  String $name The name to look for
	 * @return Array        The array of Categories
	 */
	public function loadByName($name) {
		$cats = array();

		if(false !== ($categories = $this->_db->select("SELECT * FROM category WHERE cat_name LIKE :name;", array(':name' => "%$name%"), true))) {
			foreach ($categories as $key => $cat) {
				$cats[] = array(
					'id'	=>	$cat['cat_id'],
					'name'	=>	$cat['cat_name']
				);
			}
		}

		return $cats;
	}

	/**
	 * Method to remove the order
	 */
	public function remove() {
		$response = $this->_db->command("DELETE FROM category WHERE cat_id = :id OR cat_parent_id = :id;", array(':id' => $this->_id));
		return $response;
	}

	/**
	 * Method to save the values of this product to the database
	 */
	public function save() {
		// Insert, but when already in the database, update
		$isInserted = ($this->_id == null) ? true : false;
		$response = $this->_db->command("INSERT INTO `category` (
			`cat_id`,
			`cat_name`,
			`cat_parent_id`
		) VALUES (
			:id,
			:name,
			:parentid
		) ON DUPLICATE KEY UPDATE
			`cat_name` = VALUES(`cat_name`),
			`cat_parent_id` = VALUES(`cat_parent_id`)
		;", array(
			':id' 		=> $this->_id,
			':name' 	=> $this->_name,
			':parentid'	=> $this->_parent_id
		), true);

		if($isInserted) $this->_id = $response['lastInsertId'];
	}

}