<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace model;
use core;

/**
 * Specifies a certain product
 */
class Address extends core\Model {

	/* Private Variables */
	private $_id = null;
	private $_street1 = null;
	private $_street2 = null;
	private $_zipcode = null;
	private $_city = null;
	private $_state = null;
	private $_country = null;
	private $_usr_id = null;

	/**
	 * Method to get the id of this address
	 * @return Integer The id
	 */
	public function getID() {
		return $this->_id;
	}

	/**
	 * Method to get the street1 of this address
	 * @return String The street1
	 */
	public function getStreet1() {
		return $this->_street1;
	}

	/**
	 * Method to get the street2 of this address
	 * @return String The street2
	 */
	public function getStreet2() {
		return $this->_street2;
	}

	/**
	 * Method to get the zipcode of this address
	 * @return String The zipcode
	 */
	public function getZipcode() {
		return $this->_zipcode;
	}

	/**
	 * Method to get the city of this address
	 * @return String The city
	 */
	public function getCity() {
		return $this->_city;
	}

	/**
	 * Method to get the state of this address
	 * @return String The state
	 */
	public function getState() {
		return $this->_state;
	}

	/**
	 * Method to get the country of this address
	 * @return String The country
	 */
	public function getCountry() {
		return $this->_country;
	}

	/**
	 * Method to get the usr_id of this address
	 * @return Integer The user ID
	 */
	public function getUserID() {
		return $this->_usr_id;
	}

	/**
	 * Method to set the id of this address
	 * @param Integer $value The id
	 */
	public function setID($value) {
		if(false === ($value = $this->checkField($value, 'int', 1)))
			throw new \Exception("U dient een nummer in te vullen.");

		$this->_id = $value;
	}

	/**
	 * Method to set the street1 of this address
	 * @param String $value The street1
	 */
	public function setStreet1($value) {
		if(false === ($value = $this->checkField($value, 'string', 2)))
			throw new \Exception("Geef een geldige adres op.", 1);

		$this->_street1 = $value;
	}

	/**
	 * Method to set the street2 of this address
	 * @param String $value The street2
	 */
	public function setStreet2($value) {
		$this->_street2 = $value;
	}

	/**
	 * Method to set the zipcode of this address
	 * @param String $value The zipcode
	 */
	public function setZipcode($value) {
		if(false === ($value = $this->checkField($value, 'string', 6, 6)))
			throw new \Exception("Geef een geldige postcode op.", 1);

		$this->_zipcode = $value;
	}

	/**
	 * Method to set the city of this address
	 * @param String $value The city
	 */
	public function setCity($value) {
		if(false === ($value = $this->checkField($value, 'string', 2)))
			throw new \Exception("Geef een geldige woonplaats op.", 1);

		$this->_city = $value;
	}

	/**
	 * Method to set the state of this address
	 * @param String $value The state
	 */
	public function setState($value) {
		if(false === ($value = $this->checkField($value, 'string', 2)))
			throw new \Exception("Geef een geldige provincie op.", 1);

		$this->_state = $value;
	}

	/**
	 * Method to set the country of this address
	 * @param String $value The country
	 */
	public function setCountry($value) {
		if(false === ($value = $this->checkField($value, 'string', 2, 2)))
			throw new \Exception("Geef een geldige land op. En niet rommelen met de code godverdomme!", 1);

		$this->_country = $value;
	}

	/**
	 * Method to set the user of this address
	 * @param Integer $value The user ID
	 */
	public function setUser($value) {
		$this->_usr_id = $value;
	}


	/**
	 * Method to construct a new address
	 * @param Integer $id The ID of the address to be loaded
	 */
	public function __construct($id = null) {
		parent::__construct();
		if($id != null) $this->load($id);
	}

	/**
	 * Method to load the values of this address from the database
	 * @param  Integer $id The id of the address to be loaded
	 */
	public function load($id = null) {
		if($id != null) 
			$this->_id = $id;

		if($this->_id == null)
			throw new \Exception("Can not load an address witouth a valid ID");

		// Load from the database
		if(false !== ($address = $this->_db->select("SELECT * FROM address WHERE adr_id = :id;", array(':id' => $this->_id)))) {
			$this->_id		= $address['adr_id'];
			$this->_street1	= $address['adr_street1'];
			$this->_street2	= $address['adr_street2'];
			$this->_zipcode	= $address['adr_zipcode'];
			$this->_city	= $address['adr_city'];
			$this->_state	= $address['adr_state'];
			$this->_country	= $address['adr_country'];
			$this->_usr_id	= $address['adr_usr_id'];
		}
	}

	/**
	 * Method to save the data of this address to the database
	 */
	public function save() {
		// Insert, but when already in the database, update
		$isInserted = ($this->_id == null) ? true : false;
		$response = $this->_db->command("INSERT INTO `address` (
			`adr_id`,
			`adr_street1`,
			`adr_street2`,
			`adr_zipcode`,
			`adr_city`,
			`adr_state`,
			`adr_country`,
			`adr_usr_id`
		) VALUES (
			:adr_id,
			:adr_street1,
			:adr_street2,
			:adr_zipcode,
			:adr_city,
			:adr_state,
			:adr_country,
			:adr_usr_id
		) ON DUPLICATE KEY UPDATE
			`adr_street1` = VALUES(`adr_street1`),
			`adr_street2` = VALUES(`adr_street2`),
			`adr_zipcode` = VALUES(`adr_zipcode`),
			`adr_city` = VALUES(`adr_city`),
			`adr_state` = VALUES(`adr_state`),
			`adr_country` = VALUES(`adr_country`),
			`adr_usr_id` = VALUES(`adr_usr_id`)
		;", array(
			':adr_id' 		=> $this->_id,
			':adr_street1' 	=> $this->_street1,
			':adr_street2' 	=> $this->_street2,
			':adr_zipcode' 	=> $this->_zipcode,
			':adr_city' 	=> $this->_city,
			':adr_state' 	=> $this->_state,
			':adr_country' 	=> $this->_country,
			':adr_usr_id' 	=> $this->_usr_id
		), true);

		if($isInserted) $this->_id = $response['lastInsertId'];
		return ($response != false);
	}
}