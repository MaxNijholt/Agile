<?php
/**
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 */

namespace model;
use core;

/**
 * Specifies a certain product
 */
class Tag extends core\Model {

	/* Private variables */
	private $_name = null;
	private $_metaphone = null;

	/**
	 * Method to get the name of this tag
	 * @return String The name
	 */
	public function getName() {
		return $this->_name;
	}

	/**
	 * Method to get the metaphone string of this tag
	 * @return String The metaphone string
	 */
	public function getMetaphone() {
		return $this->_metaphone;
	}

	/**
	 * Method to set the name of this tag
	 * @param String $value The name
	 */
	public function setName($value) {
		$this->_name = $value;
		$this->_metaphone = metaphone($this->_name);
	}

	/**
	 * Method to set the metaphone string of this tag
	 * @param String $value The metaphone string
	 */
	public function setMetaphone($value) {
		$this->_metaphone = $value;
	}
	

	/**
	 * Method to construct a new tag
	 * @param String $name The name of the tag
	 */
	public function __construct($name = null) {
		parent::__construct();
		if($name != null) $this->load($name);
	}

	/**
	 * Method to load the values of this product from the database
	 */
	public function load($name = null) {
		if($name != null) 
			$this->_name = $name;

		if($this->_name == null)
			throw new \Exception("Can not load a tag witouth a valid ID");

		// Load from the database
		if(false !== ($tag = $this->_db->select("SELECT * FROM tag WHERE tag = ':tag';", array(':tag' => $this->_name)))) {
			$this->_name 		= $tag['tag'];
			$this->_metaphone 	= $tag['tag_metaphone'];
		}
	}

	/**
	 * Method to search for tags by a string
	 * @param  String $query The name of the tag to search for
	 * @return Array         The array of tags found
	 */
	public function loadTagsBySearch($query) {
		$tarray = array();
		if(false !== ($tags = $this->_db->select("SELECT * FROM tag WHERE tag LIKE :name OR tag_metaphone LIKE :metaphone;", array(':name' => "%$query%", ':metaphone' => metaphone($query)), true))) {
			foreach ($tags as $key => $tag) 
				$tarray[] = $tag['tag'];
		}
		return $tarray;
	}

	/**
	 * Method to save the values of this tag to the database
	 */
	public function save() {
		// Insert, but when already in the database, update
		$isInserted = ($this->_id == null) ? true : false;
		$response = $this->_db->command("INSERT INTO `tag` (
			`tag`,
			`tag_metaphone`
		) VALUES (
			:tag,
			:metaphone
		) ON DUPLICATE KEY UPDATE
			`tag_metaphone` = VALUES(`tag_metaphone`)
		;", array(
			':tag'			=> $this->_name,
			':metaphone'	=> $this->_metaphone
		), true);

		if($isInserted) $this->_id = $response['lastInsertId'];
	}

}