<!--
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 -->
<div class="row">
	<div class="col-md-4">
		<h2><?=$product1->getName()?></h2>
		<a href="/product/<?=$product1->getID()?>"><img src="/media/products/<?=$product1->getID()?>.jpg" alt="<?=$product1->getName()?>" height="250"></a>
		<p><?=$product1->getDesc()?></p>
		<hr>
		<label class="visible-inline">Prijs:</label>
		<p class="visible-inline"><?=$product1->getPrice()?></p>
	</div>
	<div class="col-md-4">
		<h2><?=$product2->getName()?></h2>
		<a href="/product/<?=$product2->getID()?>"><img src="/media/products/<?=$product2->getID()?>.jpg" alt="<?=$product2->getName()?>" height="250"></a>
		<p><?=$product1->getDesc()?></p>
		<hr>
		<label class="visible-inline">Prijs:</label>
		<p class="visible-inline"><?=$product2->getPrice()?></p>
	</div>
	<?php if($product3 != false): ?>
	<div class="col-md-4">
		<h2><?=$product3->getName()?></h2>
		<a href="/product/<?=$product3->getID()?>"><img src="/media/products/<?=$product3->getID()?>.jpg" alt="<?=$product3->getName()?>" height="250"></a>\
		<p><?=$product1->getDesc()?></p>
		<hr>
		<label class="visible-inline">Prijs:</label>
		<p class="visible-inline"><?=$product3->getPrice()?></p>
	</div>
	<?php endif ?>
</div>