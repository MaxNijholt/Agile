<!--
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 -->
<article class="account">
	
	<div class="row">
		<div class="col-md-12">
			<h1>About</h1>
			<hr />
		</div>
	</div>

	<div class="row">
		<div class="col-md-6">
			<h2>Roel Ernens</h2>
			<p>De samenwerking ging goed. We hebben alles eerlijk verdeeld. Iedereen heeft van alles wat gedaan.</p>
		</div>
		<div class="col-md-6">
			<h2>Stephan R&ouml;mer</h2>
			<p>We hebben beide gewerkt aan deze website. Gezamenlijk hebben we alles ingevuld. Ging erg goed. (We werken al lang bij hetzelfde bedrijf, dus samenwerken kunnen we wel ;)</p>
		</div>
	</div>

</article>