<!--
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 -->
<article id="order">	
	<h2>Orders</h2>
	<?php if (count($orders) > 0): ?>
		<table class="table table-striped">
			<tr>
				<th>Ordernummer</th>
				<th>Datum</th>
				<th>Totaal</th>
				<th>Status</th>
			</tr>
			<?php foreach ($orders as $order): ?>
				<tr>
					<td><a href="/order/<?=$order->getId()?>"><?=$order->getId()?></a></td>
					<td><?=$order->getTimestamp()?></td>
					<td><?=$formatter->formatCurrency($order->getTotalVAT(), 'EUR')?></td>
					<td><?=$order->getStatus()?></td>
				</tr>
			<?php endforeach; ?>
		</table>
	<?php else: ?>
		<h3>Er zijn geen orders</h3>
	<?php endif; ?>
</article>	