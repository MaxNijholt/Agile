<!--
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 -->
<article class="search">
	<div class="row">
		<div class="col-md-12">
			<h1>Zoeken<?php if(isset($_GET['query'])) echo " '" . htmlspecialchars($_GET['query']) ."':"; else echo ':'; ?></h1>
			<hr />
		</div>
	</div>
	
	<?php if(count($products) > 0): ?>
		<div class="row">
			<div class="col-md-12">
				<p>Er zijn <?=count($products)?> product(en) gevonden:</p>
				<hr />
			</div>
		</div>
		<?php foreach($products as $product): ?>
			<div class="row product">
				<div class="col-md-3"><img src="/media/products/<?=$product->getID()?>.jpg" width="100%" /></div>
				<div class="col-md-9">
					<h2><?=$product->getName()?></h2>
					<div class="description">
						<p><?=$product->getDesc('long')?></p>
					</div>
					<div class="tags">
						<?php foreach ($product->getTags() as $tag): ?>
							<span class="label label-primary"><span class="glyphicon glyphicon-tags"></span>&nbsp;<?=$tag->getName()?></span>
						<?php endforeach; ?>
					</div>
					<hr />
					<p class="visible-inline">Prijs: </p> <p class="lead visible-inline"><?=$formatter->formatCurrency($product->getPrice(), 'EUR')?></p> 
					<a onclick="addProduct(<?=$product->getID()?>, this);" class="btn btn-success btn-lg pull-right" data-loading-text="Toegevoegd"><span class="glyphicon glyphicon-shopping-cart"></span> Toevoegen</a>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12"><hr /></div>
			</div>
		<?php endforeach; ?>
	<?php else: ?>
		<div class="row">
			<div class="col-md-12">
				<i>Er zijn helaas geen zoekresultaten met deze term.</i>
			</div>
		</div>
	<?php endif; ?>
</article>