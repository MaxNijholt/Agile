<!--
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 -->
<article class="account">
	<div class="row">
		<div class="col-md-12">
			<h1>Goedendag!</h1>
		</div>
	</div>

	<div class="row">
		<div class="col-md-12">
			<p>Ga naar:</p>
			<a href="/order">Mijn Bestellingen</a><br />
			<?php if($user->isAdmin()): ?><a href="/admin">Admin</a><?php endif; ?>
		</div>
	</div>
</article>