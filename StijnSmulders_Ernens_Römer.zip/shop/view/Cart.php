<!--
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 -->
<article id="cart">
	<h2>Winkelwagen</h2>
	<?php if(count($products) > 0): ?>
	<table class="table table-striped">
		<tr>
			<th>Artikel</th>
			<th>Prijs</th>
			<th>Aantal</th>
			<th colspan="2">Totaal</th>
		</tr>
		<?php foreach ($products as $id => $product): ?>
		<tr id="<?=$id?>" class="product">
			<td>
				<img height="75" width="75" alt="<?=$product[1]['name']?>" src="/media/products/<?=$id?>.jpg">
				<span><?=$product[1]['name']?></span>
			</td>
			<td class="productPrice" data-vat="<?=$product[1]['price']*($product[1]['vat']/100)?>"><?=$formatter->formatCurrency($product[1]['price'], 'EUR')?></td>
			<td class="productAmount"><input type="number" value="<?=$product[0]?>" onchange="amountChange(<?=$id?>)"></td>
			<td class="productTotal"><?=$formatter->formatCurrency($product[1]['price']*$product[0], 'EUR')?></td>
			<td><a onclick="removeProduct(<?=$id?>)">Verwijderen</a></td>
		</tr>
		<?php endforeach; ?>
		<tr class="cartTotal">
			<td colspan="3" class="right">Totaal excl.</td>
			<td id="totalExcl" colspan="2"><?=$formatter->formatCurrency($excl, 'EUR')?></td>
		</tr>
		<tr class="cartTotal">
			<td colspan="3" class="right">BTW</td>
			<td id="totalVat" colspan="2"><?=$formatter->formatCurrency($btw, 'EUR')?></td>
		</tr>
		<tr class="cartTotal">
			<td colspan="3" class="right">Totaal</td>
			<td id="total" colspan="2"><?=$formatter->formatCurrency($total, 'EUR')?></td>
		</tr>
		<tr class="cartTotal">
			<td colspan="5" class="right">
				<a href="/cart/checkout" class="btn btn-primary">Bestellen</a>
			</td>
		</tr>
	</table>
	<?php else: ?>
	<h3>De winkelwagen is leeg</h3>
	<?php endif; ?>
</article>