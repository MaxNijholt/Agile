<!--
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 -->
<article class="logout">
	<div class="container">
		<div class="col-md-12">
			<h2>Uitloggen</h2>
			<hr />
			<div class="alert alert-success"><b>Uitgelogd!</b><span class="pull-right">U bent successvol uitgelogd.</span></div>
			<p>Klik <a href="/">hier</a> om terug te gaan naar de hoofdpagina.</p>
		</div>
	</div>	
</article>