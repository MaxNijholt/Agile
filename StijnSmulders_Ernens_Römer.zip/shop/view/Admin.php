<!--
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 -->
<article class="admin container">
	<div class="row">
		<div class="col-md-12">
			<h1>Admin</h1>
			<hr />
		</div>
	</div>
	<div class="row">
		<?php include $_SERVER['DOCUMENT_ROOT'] . 'shop/view/Admin/menu.tpl.php'; ?>
		<div class="col-md-8"><p>Kies links een categorie om te beginnen.</p></div>
	</div>
</article>