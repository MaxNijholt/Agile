<!--
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 -->
<article id="cart">
	<table class="table table-striped">
		<tr>
			<th>Artikel</th>
			<th>Prijs</th>
			<th>Aantal</th>
			<th>Totaal</th>
		</tr>
		<?php foreach ($products as $id => $product): ?>
		<tr id="<?=$id?>" class="product">
			<td><?=$product[1]['name']?></td>
			<td class="productPrice" data-vat="<?=$product[1]['price']*($product[1]['vat']/100)?>"><?=$formatter->formatCurrency($product[1]['price'], 'EUR')?></td>
			<td class="productAmount"><?=$product[0]?></td>
			<td class="productTotal"><?=$formatter->formatCurrency($product[1]['price']*$product[0], 'EUR')?></td>
		</tr>
		<?php endforeach; ?>
		<tr class="cartTotal">
			<td colspan="3" class="right">Totaal excl.</td>
			<td id="totalExcl"><?=$formatter->formatCurrency($excl, 'EUR')?></td>
		</tr>
		<tr class="cartTotal">
			<td colspan="3" class="right">BTW</td>
			<td id="totalVat"><?=$formatter->formatCurrency($btw, 'EUR')?></td>
		</tr>
		<tr class="cartTotal">
			<td colspan="3" class="right">Totaal</td>
			<td id="total"><?=$formatter->formatCurrency($total, 'EUR')?></td>
		</tr>
	</table>
</article>
<div id="checkout">
	<div class="container">
		<form action="/order/add" method="post">
			<h3>Adresgegevens</h3>
			<?php foreach ($address as $key => $value): ?>
				<div class="radio">
					<label>
					    <input type="radio" name="adres" value="<?=$value->getId()?>" onclick="chooseAdres(this);" <?php if ($key == 0) echo "checked"; ?>>
					    <?=$value->getStreet1()?> - <?=$value->getZipcode()?> - <?=$value->getCity()?>
					</label>
				</div>
				<div id="<?=$value->getId()?>" class="existsAdres" <?php if ($key != 0) echo 'style="display:none;"'; ?>>
					<div class="form-group">
						<label>Adres 1:</label>
						<span><?=$value->getStreet1()?></span>
					</div>
					<div class="form-group">
						<label>Adres 2:</label>
						<span><?=$value->getStreet2()?></span>
					</div>
					<div class="form-group">
						<label>Postcode:</label>
						<span><?=$value->getZipcode()?></span>
					</div>
					<div class="form-group">
						<label>Woonplaats:</label>
						<span><?=$value->getCity()?></span>
					</div>
					<div class="form-group">
						<label>Procincie:</label>
						<span><?=$value->getState()?></span>
					</div>
					<div class="form-group">
						<label>Land:</label>
						<span><?=$value->getCountry()?></span>
					</div>
				</div>
			<?php endforeach; ?>
			<div class="radio">
				<label>
				    <input type="radio" name="adres" value="new" onclick="chooseAdres(this);">
				    Ander adress
				</label>
			</div>
			<div id="newAdres" style="display: none;">
				<div class="form-group">
					<label>Adres 1</label>
					<input type="text" name="street1" class="form-control" placeholder="Adresregel 1" />
				</div>

				<div class="form-group">
					<label>Adres 2</label>
					<input type="text" name="street2" class="form-control" placeholder="Adresregel 2" />
				</div>

				<div class="form-group">
					<label>Postcode</label>
					<input type="text" name="zipcode" class="form-control" placeholder="Postcode" />
				</div>

				<div class="form-group">
					<label>Woonplaats</label>
					<input type="text" name="city" class="form-control" placeholder="Woonplaats" />
				</div>

				<div class="form-group">
					<label>Provincie</label>
					<input type="text" name="state" class="form-control" placeholder="Provincie" />
				</div>

				<div class="form-group">
					<label>Land</label>
					<select name="country" class="form-control">
						<option value="NL">Nederland</option>
						<option value="BE">Belgi&euml;</option>
					</select>
				</div>
			</div>
			<button name="submit" type="submit" class="btn btn-primary">Plaats order</button>
		</form>
	</div>
</div>
