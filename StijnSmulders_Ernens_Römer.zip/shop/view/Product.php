<!--
 * @author Roel Ernens   info@roelernens.nl
 * @author Stephan Römer info@stephanromer.nl
 -->
<article class="product container">
	<div class="row">
		<div class="col-md-12">
			<h1><?=$name;?></h1>
			<?php if (!isset($id)): ?><?=$desc;?><?php endif; ?>
		</div>
	</div>

	<?php if (isset($id)): ?>
	<div class="row">
		<div class="col-md-12">
			<div class="description">
				<img align="left" src="/media/products/<?=$id?>.jpg" width="300" />
				<?=$desc?>
			</div>

			<div class="actions">
				<p class="lead"><?=$formatter->formatCurrency($price, 'EUR')?></p> <a onclick="addProduct(<?=$id?>)" class="btn btn-success btn-lg"><span class="glyphicon glyphicon-shopping-cart"></span> Toevoegen</a>
			</div>

			<div class="tags">
				<?php foreach ($tags as $key => $value): ?>
					<span class="label label-primary"><span class="glyphicon glyphicon-tags"></span>&nbsp;<?=$value->getName()?></span>
				<?php endforeach; ?>
			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-md-12"><hr /></div>
	</div>

	<div class="row">
		<div class="col-md-12">
			<h3>Producten die je misschien ook leuk vind?</h3>
		</div>
	</div>

	<div class="row">
	<?php foreach ($similiar as $product): ?>
		<div class="col-xs-6 col-md-3">
			<a href="/product/<?=$product->getID()?>" class="thumbnail">
				<img src="/media/products/<?=$product->getID()?>.jpg" alt="<?=$product->getName();?>">
			</a>
		</div>
	<?php endforeach; ?>
	</div>
	<?php endif; ?>
</article>